# Общая демонстрация функционала
![ezgif-5-e5292902c5](https://github.com/sirgb1/flutter4/assets/96747393/8d1ea393-66d0-4a98-9e3e-4131a490069e)

# Главная страница
![image](https://github.com/sirgb1/flutter4/assets/96747393/8af3bee0-08dc-425c-907b-a1404bb1d6ee)

# Карточка с товаром
![image](https://github.com/sirgb1/flutter4/assets/96747393/5b08cb06-eb53-4979-a585-88c243de1f47)
